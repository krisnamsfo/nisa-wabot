const dotenv = require('dotenv');
dotenv.config();

module.exports = {
    port: process.env.PORT || 3000,
    nisa: {
        username: process.env.NISA_USERNAME,
        password: process.env.NISA_PASSWORD
    },
    targetPhone: process.env.TARGET_PHONE
};

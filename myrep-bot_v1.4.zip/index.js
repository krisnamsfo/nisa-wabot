// =========================================================================
// BARIS UTAMA: AKTIFKAN DOTENV AGAR BISA MEMBACA FILE .ENV
// =========================================================================
require('dotenv').config();

const express = require('express');
const { initWhatsApp, sendMessage } = require('./handlers/whatsappHandler');
const { scrapeNisa, scrapeGamasSemarang, scrapePreMpSemarang } = require('./scrapers/nisaScraper'); 
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;

// Cache terpisah agar notifikasi tidak spam
let infoGamasTerakhir = ""; 
let infoFatlossTerakhir = ""; 
let infoPreMpTerakhir = ""; 

// Fungsi Pembantu Mengambil Daftar ID Grup secara dinamis dari database.json
function getDaftarGrup() {
    const dbPath = path.join(__dirname, './database.json');
    if (!fs.existsSync(dbPath)) {
        console.error('[Auto Update] File database.json tidak ditemukan!');
        return [];
    }
    try {
        const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
        // Disamakan menggunakan 'daftarGrup' sesuai isi database.json
        return db.daftarGrup || []; 
    } catch (e) {
        console.error('[Auto Update] Gagal membaca file database.json:', e.message);
        return [];
    }
}

// Endpoint trigger monitoring manual/cron
app.post('/api/monitor', async (req, res) => {
    // Ambil langsung dari file .env secara aman
    const username = req.body.username || process.env.NISA_USER;
    const password = req.body.password || process.env.NISA_PASSWORD;
    const phone = req.body.target_phone || '6281333148055'; // Nilai cadangan langsung

    res.status(202).json({ message: 'Proses monitoring berjalan di background.' });

    console.log('[System] Memulai trigger monitoring...');
    const result = await scrapeNisa(username, password);

    const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    if (result.success) {
        const pesan = `*--- LAPORAN MONITORING NISA ---*\n\nWaktu: ${waktu}\n\n*Data:* \n${result.data}`;
        await sendMessage(phone, pesan);
    } else {
        const pesanGagal = `❌ *Monitoring Gagal!*\nWaktu: ${waktu}\nError: ${result.error}`;
        await sendMessage(phone, pesanGagal);
    }
});

// Pastikan definisi path file cache ini berada di bagian atas file index.js
const PATH_CACHE_GAMAS = path.join(__dirname, 'cacheGamas.json');
const PATH_CACHE_FATLOSS = path.join(__dirname, 'cacheFatloss.json');
const PATH_CACHE_PREMP = path.join(__dirname, 'cachePreMp.json');
const PATH_DATABASE = path.join(__dirname, 'database.json');



// 1. Pengecekan Gamas OLT Semarang
async function cekGamasOtomatis() {
    try {
        console.log(`[${new Date().toLocaleTimeString('id-ID')}] [Auto Gamas] Mengecek data terbaru...`);
        const hasil = await scrapeGamasSemarang(process.env.NISA_USER, process.env.NISA_PASSWORD);
        
        if (!hasil || !hasil.success) {
            console.error('[Auto Gamas] Gagal mengambil data atau sukses bernilai false');
            return;
        }

        const dataSekarang = hasil.data ? hasil.data.trim() : '';
        
        // 1. Ambil cache lama berbentuk Array
        let cacheTiketLama = [];
        if (fs.existsSync(PATH_CACHE_GAMAS)) {
            try { cacheTiketLama = JSON.parse(fs.readFileSync(PATH_CACHE_GAMAS, 'utf-8')); } catch (e) { cacheTiketLama = []; }
        }

        // 2. Ekstrak No Tiket dari data sekarang (Spesifik Gamas: MP)
        const regexGamas = /(?:MP)\d+[A-Z0-9]*/g;
        const tiketMentah = dataSekarang.match(regexGamas) || [];
        const tiketSaatIni = [...new Set(tiketMentah)]; // Hilangkan Duplikat

        // KONDISI JIKA DATA CLEAN / KOSONG / SEMUA DONE
        if (!dataSekarang || dataSekarang.includes('tidak ada') || dataSekarang === '' || tiketSaatIni.length === 0) {
            if (cacheTiketLama.length > 0) {
                console.log('[Auto Gamas] Deteksi semua gangguan GAMAS OLT clear/done!');
                const dbData = JSON.parse(fs.readFileSync(PATH_DATABASE, 'utf-8'));
                const idGrup = dbData.daftarGrup?.gamas;
                if (idGrup) {
                    let pesanDone = `🎉 *NOTIFIKASI SELURUH GANGGUAN GAMAS OLT DONE (SEMARANG)* 🎉\n\n`;
                    cacheTiketLama.forEach(noTiket => { pesanDone += `✅ Tiket *${noTiket}* -> CLOSED/DONE\n`; });
                    await sendMessage(idGrup, pesanDone);
                }
                fs.writeFileSync(PATH_CACHE_GAMAS, JSON.stringify([], null, 2), 'utf-8');
            }
            return;
        }

        // KONDISI RUNNING PERTAMA KALI
        if (!fs.existsSync(PATH_CACHE_GAMAS)) {
            fs.writeFileSync(PATH_CACHE_GAMAS, JSON.stringify(tiketSaatIni, null, 2), 'utf-8');
            console.log('[Auto Gamas] Cache awal No. Tiket berhasil disimpan.');
            return;
        }

        const dbData = JSON.parse(fs.readFileSync(PATH_DATABASE, 'utf-8'));
        const idGrup = dbData.daftarGrup?.gamas;

        if (idGrup) {
            // DETEKSI TIKET BARU
            const tiketBaru = tiketSaatIni.filter(noTiket => !cacheTiketLama.includes(noTiket));
            if (tiketBaru.length > 0) {
                console.log(`[Auto Gamas] Deteksi tiket baru: ${tiketBaru.join(', ')}`);
                const pesanNotif = `📢 *NOTIFIKASI PUSH GAMAS OLT BARU (SEMARANG)* 📢\n\n${dataSekarang}\n\n📌 *Tiket Baru:* ${tiketBaru.join(', ')}`;
                await sendMessage(idGrup, pesanNotif);
            }

            // DETEKSI TIKET DONE / CLOSED
            const tiketYangSelesai = cacheTiketLama.filter(noTiket => !tiketSaatIni.includes(noTiket));
            if (tiketYangSelesai.length > 0) {
                console.log(`[Auto Gamas] Deteksi tiket closed: ${tiketYangSelesai.join(', ')}`);
                let pesanDone = `✅ *NOTIFIKASI GANGGUAN GAMAS DONE (SEMARANG)* ✅\n\n`;
                tiketYangSelesai.forEach(noTiket => { pesanDone += `📌 Tiket OLT *${noTiket}* telah Selesai/Closed.\n`; });
                await sendMessage(idGrup, pesanDone);
            }
        }

        fs.writeFileSync(PATH_CACHE_GAMAS, JSON.stringify(tiketSaatIni, null, 2), 'utf-8');
    } catch (error) {
        console.error('[Auto Gamas] Error:', error.message);
    }
}

// 2. Pengecekan Fatloss Open
async function cekFatlossOtomatis() {
    try {
        console.log(`[${new Date().toLocaleTimeString('id-ID')}] [Auto Fatloss] Mengecek data terbaru...`);
        const hasil = await scrapeNisa(process.env.NISA_USER, process.env.NISA_PASSWORD);
        
        if (!hasil || !hasil.success) {
            console.error('[Auto Fatloss] Gagal mengambil data');
            return;
        }

        const dataSekarang = hasil.data ? hasil.data.trim() : '';
        
        let cacheTiketLama = [];
        if (fs.existsSync(PATH_CACHE_FATLOSS)) {
            try { cacheTiketLama = JSON.parse(fs.readFileSync(PATH_CACHE_FATLOSS, 'utf-8')); } catch (e) { cacheTiketLama = []; }
        }

        // Ekstrak No Tiket spesifik berawalan FT
        const regexFatloss = /FT\d+[A-Z0-9]*/g;
        const tiketMentah = dataSekarang.match(regexFatloss) || [];
        const tiketSaatIni = [...new Set(tiketMentah)]; // Hilangkan Duplikat

        if (!dataSekarang || dataSekarang.includes('tidak ada') || dataSekarang === '' || tiketSaatIni.length === 0) {
            if (cacheTiketLama.length > 0) {
                console.log('[Auto Fatloss] Deteksi semua tiket Fatloss clear/done!');
                const dbData = JSON.parse(fs.readFileSync(PATH_DATABASE, 'utf-8'));
                const idGrup = dbData.daftarGrup?.fatloss;
                if (idGrup) {
                    let pesanDone = `🎉 *NOTIFIKASI SELURUH TIKET FATLOSS DONE* 🎉\n\n`;
                    cacheTiketLama.forEach(noTiket => { pesanDone += `✅ Tiket *${noTiket}* -> CLOSED/DONE\n`; });
                    await sendMessage(idGrup, pesanDone);
                }
                fs.writeFileSync(PATH_CACHE_FATLOSS, JSON.stringify([], null, 2), 'utf-8');
            }
            return;
        }

        if (!fs.existsSync(PATH_CACHE_FATLOSS)) {
            fs.writeFileSync(PATH_CACHE_FATLOSS, JSON.stringify(tiketSaatIni, null, 2), 'utf-8');
            console.log('[Auto Fatloss] Cache awal No. Tiket berhasil disimpan.');
            return;
        }

        const dbData = JSON.parse(fs.readFileSync(PATH_DATABASE, 'utf-8'));
        const idGrup = dbData.daftarGrup?.fatloss;

        if (idGrup) {
            const tiketBaru = tiketSaatIni.filter(noTiket => !cacheTiketLama.includes(noTiket));
            if (tiketBaru.length > 0) {
                console.log(`[Auto Fatloss] Deteksi tiket baru: ${tiketBaru.join(', ')}`);
                const pesanNotif = `⚠️ *NOTIFIKASI PUSH FATLOSS OPEN BARU* ⚠️\n\n${dataSekarang}\n\n📌 *Tiket Baru:* ${tiketBaru.join(', ')}`;
                await sendMessage(idGrup, pesanNotif);
            }

            const tiketYangSelesai = cacheTiketLama.filter(noTiket => !tiketSaatIni.includes(noTiket));
            if (tiketYangSelesai.length > 0) {
                console.log(`[Auto Fatloss] Deteksi tiket closed: ${tiketYangSelesai.join(', ')}`);
                let pesanDone = `✅ *NOTIFIKASI TIKET CLOSED (FATLOSS)* ✅\n\n`;
                tiketYangSelesai.forEach(noTiket => { pesanDone += `📌 Tiket *${noTiket}* telah diselesaikan oleh tim lapangan.\n`; });
                await sendMessage(idGrup, pesanDone);
            }
        }

        fs.writeFileSync(PATH_CACHE_FATLOSS, JSON.stringify(tiketSaatIni, null, 2), 'utf-8');
    } catch (error) {
        console.error('[Auto Fatloss] Error:', error.message);
    }
}

// 3. Pengecekan Pre-MP Open Semarang + Validasi Cross-Check ke GAMAS
async function cekPreMpOtomatis() {
    try {
        console.log(`[${new Date().toLocaleTimeString('id-ID')}] [Auto Pre-MP] Mengecek data terbaru Semarang...`);
        const hasil = await scrapePreMpSemarang(process.env.NISA_USER, process.env.NISA_PASSWORD);
        
        if (!hasil || !hasil.success) {
            console.error('[Auto Pre-MP] Gagal mengambil data Pre-MP');
            return;
        }

        const dataSekarang = hasil.data ? hasil.data.trim() : '';
        
        let cachePreMpLama = [];
        if (fs.existsSync(PATH_CACHE_PREMP)) {
            try { cachePreMpLama = JSON.parse(fs.readFileSync(PATH_CACHE_PREMP, 'utf-8')); } catch (e) { cachePreMpLama = []; }
        }

        // AMBIL ID_TMAS (Angka murni 5-8 digit)
        const regexIDTmas = /\b\d{5,8}\b/g;
        const tiketMentah = dataSekarang.match(regexIDTmas) || [];
        const cachePreMpSekarang = [...new Set(tiketMentah)]; // Hilangkan Duplikat

        // KONDISI JIKA DATA CLEAN / KOSONG / SEMUA DONE LANGSUNG DARI SOURCE PREMP
        if (!dataSekarang || dataSekarang.includes('tidak ada') || dataSekarang === '' || cachePreMpSekarang.length === 0) {
            if (cachePreMpLama.length > 0) {
                console.log('[Auto Pre-MP] Source kosong. Memproses pembersihan dengan validasi silang...');
                // Dilempar ke blok pemrosesan kehilangan di bawah untuk memastikan apakah dilempar ke gamas atau close murni
            } else {
                return;
            }
        }

        // KONDISI RUNNING PERTAMA KALI
        if (!fs.existsSync(PATH_CACHE_PREMP)) {
            fs.writeFileSync(PATH_CACHE_PREMP, JSON.stringify(cachePreMpSekarang, null, 2), 'utf-8');
            console.log('[Auto Pre-MP] Cache awal ID_Tmas berhasil disimpan.');
            return;
        }

        const dbData = JSON.parse(fs.readFileSync(PATH_DATABASE, 'utf-8'));
        const idGrupPreMp = dbData.daftarGrup?.premp;
        const idGrupGamas = dbData.daftarGrup?.gamas;

        if (idGrupPreMp) {
            // DETEKSI ID_TMAS BARU MASUK PRE-MP
            const tiketBaru = cachePreMpSekarang.filter(idTmas => !cachePreMpLama.includes(idTmas));
            if (tiketBaru.length > 0) {
                console.log(`[Auto Pre-MP] Deteksi ID_Tmas baru: ${tiketBaru.join(', ')}`);
                const pesanNotif = `🚨 *NOTIFIKASI PUSH PRE-MP OPEN BARU (SEMARANG)* 🚨\n\n${dataSekarang}\n\n📌 *ID Tmas Baru:* ${tiketBaru.join(', ')}`;
                await sendMessage(idGrupPreMp, pesanNotif);
            }

            // DETEKSI ID_TMAS YANG HILANG (Validasi: Apakah Close Murni atau Eskalasi ke GAMAS)
            const tiketYangHilang = cachePreMpLama.filter(idTmas => !cachePreMpSekarang.includes(idTmas));
            
            if (tiketYangHilang.length > 0) {
                console.log(`[Auto Pre-MP] Mendeteksi ${tiketYangHilang.length} ID_Tmas hilang. Melakukan validasi silang ke GAMAS OLT...`);
                
                // Tarik data Gamas terbaru secara instan untuk melakukan cross-check
                const hasilGamas = await scrapeGamasSemarang(process.env.NISA_USER, process.env.NISA_PASSWORD);
                const dataGamasTerbaru = (hasilGamas && hasilGamas.success && hasilGamas.data) ? hasilGamas.data.trim() : '';

                for (const idTmas of tiketYangHilang) {
                    // Validasi jika ID_Tmas yang hilang terselip di dalam teks laporan GAMAS terbaru
                    if (dataGamasTerbaru && dataGamasTerbaru.includes(idTmas)) {
                        console.log(`[Auto Pre-MP] Valid! ID_Tmas ${idTmas} LOMPAT menjadi GAMAS OLT.`);
                        
                        // Cari nomor tiket GAMAS barunya (berawalan MP)
                        const regexNoGamas = /(?:MP)\d+[A-Z0-9]*/g;
                        const semuaGamasMatch = dataGamasTerbaru.match(regexNoGamas) || [];
                        
                        let cacheGamasLama = [];
                        if (fs.existsSync(PATH_CACHE_GAMAS)) {
                            try { cacheGamasLama = JSON.parse(fs.readFileSync(PATH_CACHE_GAMAS, 'utf-8')); } catch (e) { cacheGamasLama = []; }
                        }

                        // Temukan nomor tiket gamas baru yang belum terdaftar di cache gamas lama
                        const noTiketGamasBaru = semuaGamasMatch.find(noTiket => !cacheGamasLama.includes(noTiket)) || "TIDAK TERDETEKSI (Cek Manual)";

                        // Suntik tiket baru tersebut ke cacheGamas.json agar fungsi cekGamasOtomatis tidak mengirim push ganda
                        if (noTiketGamasBaru !== "TIDAK TERDETEKSI (Cek Manual)") {
                            cacheGamasLama.push(noTiketGamasBaru);
                            fs.writeFileSync(PATH_CACHE_GAMAS, JSON.stringify([...new Set(cacheGamasLama)], null, 2), 'utf-8');
                        }

                        // Kirim push alert eskalasi khusus ke Grup GAMAS
                        if (idGrupGamas) {
                            let pesanEskalasi = `📢 *ESKALASI PRE-MP KE GAMAS OLT (SEMARANG)* 📢\n`;
                            pesanEskalasi += `========================================\n\n`;
                            pesanEskalasi += `Status investigasi *ID Tmas ${idTmas}* telah selesai dan dialihkan menjadi gangguan massal resmi!\n\n`;
                            pesanEskalasi += `📌 *ID Tmas Asal:* ${idTmas}\n`;
                            pesanEskalasi += `🎟️ *No Tiket GAMAS Baru:* *${noTiketGamasBaru}*\n\n`;
                            pesanEskalasi += `_Laporan lengkap gangguan silakan pantau notifikasi masuk berikutnya atau ketik .menu_`;
                            
                            await sendMessage(idGrupGamas, pesanEskalasi);
                        }
                    } else {
                        // JIKA TIDAK ADA DI GAMAS (Fix Close Murni/Done)
                        console.log(`[Auto Pre-MP] ID_Tmas ${idTmas} tidak ada di GAMAS. Fix Closed Murni.`);
                        
                        let pesanDone = `✅ *NOTIFIKASI TIKET CLOSED (PRE-MP SEMARANG)* ✅\n\n`;
                        pesanDone += `📌 Investigasi untuk ID Tmas *${idTmas}* telah Selesai/Closed di sistem tanpa eskalasi massal.\n`;
                        
                        await sendMessage(idGrupPreMp, pesanDone);
                    }
                }
            }
        }

        fs.writeFileSync(PATH_CACHE_PREMP, JSON.stringify(cachePreMpSekarang, null, 2), 'utf-8');
    } catch (error) {
        console.error('[Auto Pre-MP] Error:', error.message);
    }
}



// BATAS


// =========================================================================
// FITUR BARU: KIRIM RANGKUMAN TIKET AKTIF SETIAP 1 JAM SEKALI
// =========================================================================
async function kirimRangkumanRutin() {
    try {
        console.log(`[${new Date().toLocaleTimeString('id-ID')}] 🕒 [Rangkuman Jam] Memproses rangkuman rutin ke grup...`);
        
        // Baca database.json untuk mendapatkan target grup WhatsApp
        if (!fs.existsSync(PATH_DATABASE)) return;
        const dbData = JSON.parse(fs.readFileSync(PATH_DATABASE, 'utf-8'));
        
        // -----------------------------------------------------------------
        // 1. RANGKUMAN TIKET FATLOSS
        // -----------------------------------------------------------------
        if (fs.existsSync(PATH_CACHE_FATLOSS) && dbData.daftarGrup?.fatloss) {
            const cacheFatloss = JSON.parse(fs.readFileSync(PATH_CACHE_FATLOSS, 'utf-8'));
            if (cacheFatloss.length > 0) {
                let pesan = `🕒 *PENGINGAT RUTIN: DAFTAR TIKET FATLOSS OPEN* 🕒\n`;
                pesan += `========================================\n\n`;
                pesan += `Saat ini masih terdapat *${cacheFatloss.length}* tiket open yang memerlukan penanganan:\n\n`;
                cacheFatloss.forEach((noTiket, index) => {
                    pesan += `${index + 1}. 📄 Tiket: *${noTiket}*\n`;
                });
                pesan += `\n💡 _Harap segera di-update jika sudah dikerjakan di lapangan._`;
                
                await sendMessage(dbData.daftarGrup.fatloss, pesan);
                console.log(`[Rangkuman Jam] Sukses mengirim list Fatloss.`);
            }
        }

        // -----------------------------------------------------------------
        // 2. RANGKUMAN TIKET GAMAS
        // -----------------------------------------------------------------
        if (fs.existsSync(PATH_CACHE_GAMAS) && dbData.daftarGrup?.gamas) {
            const cacheGamas = JSON.parse(fs.readFileSync(PATH_CACHE_GAMAS, 'utf-8'));
            if (cacheGamas.length > 0) {
                let pesan = `🕒 *PENGINGAT RUTIN: GANGGUAN GAMAS OLT* 🕒\n`;
                pesan += `========================================\n\n`;
                pesan += `⚠️ Perhatian! Masih ada *${cacheGamas.length}* gangguan GAMAS aktif:\n\n`;
                cacheGamas.forEach((noTiket, index) => {
                    pesan += `${index + 1}. 📢 Tiket: *${noTiket}*\n`;
                });
                
                await sendMessage(dbData.daftarGrup.gamas, pesan);
                console.log(`[Rangkuman Jam] Sukses mengirim list Gamas.`);
            }
        }

        // -----------------------------------------------------------------
        // 3. RANGKUMAN TIKET PRE-MP SEMARANG
        // -----------------------------------------------------------------
        if (fs.existsSync(PATH_CACHE_PREMP) && dbData.daftarGrup?.premp) {
            const cachePreMp = JSON.parse(fs.readFileSync(PATH_CACHE_PREMP, 'utf-8'));
            if (cachePreMp.length > 0) {
                let pesan = `🕒 *PENGINGAT RUTIN: TIKET PRE-MP SEMARANG* 🕒\n`;
                pesan += `========================================\n\n`;
                pesan += `Daftar tiket PRE-MP yang masih open (*${cachePreMp.length}* Tiket):\n\n`;
                cachePreMp.forEach((noTiket, index) => {
                    pesan += `${index + 1}. 🚨 Tiket: *${noTiket}*\n\n\n`;
                    pesan += `gunakan _.cekhost [tiket]_ untuk melihat detail OLT\n`;
                });
                
                await sendMessage(dbData.daftarGrup.premp, pesan);
                console.log(`[Rangkuman Jam] Sukses mengirim list Pre-MP.`);
            }
        }

    } catch (error) {
        console.error('[Rangkuman Jam] Error saat mengirim pengingat rutin:', error.message);
    }
}

// =========================================================================
// ARRANGEMENT TIMING (PEMICU WAKTU JALAN AWAL & RUTIN)
// =========================================================================

// 1. Trigger pertama: Jalankan otomatis 2 menit setelah bot running (2 menit = 120.000 ms)
setTimeout(() => {
    console.log(`[System] Menjalankan rangkuman tiket pertama (Trigger 2 Menit Awal)...`);
    kirimRangkumanRutin();
}, 2 * 60 * 1000);

// 2. Trigger rutin: Lanjutkan berkala setiap 1 jam sekali (1 jam = 3.600.000 ms)
setInterval(kirimRangkumanRutin, 60 * 60 * 1000);





// =========================================================================
// JALANKAN BACKGROUND JOB DENGAN JEDA 15 DETIK (VERSI FIX)
// =========================================================================
// Tambahkan baris ini tepat di atas fungsi jalankanSemuaPengecekan
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
// Fungsi Master untuk menjalankan semua background job dengan jeda aman
async function jalankanSemuaPengecekan() {
    console.log(`[${new Date().toLocaleTimeString('id-ID')}] 🔄 [System] Memulai rangkaian pengecekan otomatis...`);
    
    // 1. Cek Gamas OLT Semarang
    await cekGamasOtomatis();
    
    // Beri jeda 15 detik sebelum lanjut ke Fatloss
    console.log(`[System] Mengistirahatkan sesi selama 15 detik sebelum cek Fatloss...`);
    await delay(15000); 
    
    // 2. Cek Fatloss Open
    await cekFatlossOtomatis();
    
    // Beri jeda 15 detik sebelum lanjut ke Pre-MP
    console.log(`[System] Mengistirahatkan sesi selama 15 detik sebelum cek Pre-MP...`);
    await delay(15000);
    
    // 3. Cek Pre-MP Open Semarang
    await cekPreMpOtomatis();
    
    console.log(`[${new Date().toLocaleTimeString('id-ID')}] ✅ [System] Seluruh rangkaian pengecekan selesai. Menunggu interval berikutnya...`);
}

// =========================================================================
// =========================================================================
// RUN SERVER DAN BOT WA (VERSI DELAY AWAL 30 DETIK)
// =========================================================================
app.listen(PORT, () => {
    console.log(`[System] Server API aktif di port ${PORT}`);
    
    // 1. Jalankan WhatsApp Bot pertama kali
    initWhatsApp();

    // 2. Set timer rutin otomatis interval setiap 5 menit (300.000 ms)
    const JEDA_WAKTU = 5 * 60 * 1000; 
    setInterval(jalankanSemuaPengecekan, JEDA_WAKTU);
    console.log('[System] Loop pengecekan otomatis setiap 5 menit telah dijadwalkan.');

    // 3. PEMICU AWAL: Tunggu 30 detik (30.000 ms) setelah start, lalu jalankan pengecekan
    console.log('[System] Menunggu 30 detik awal agar koneksi WhatsApp stabil sebelum push notifikasi...');
    setTimeout(async () => {
        console.log('[System] 30 detik pertama tercapai! Menjalankan push notifikasi awal...');
        await jalankanSemuaPengecekan();
    }, 30000); // 30000 milidetik = 30 detik
});




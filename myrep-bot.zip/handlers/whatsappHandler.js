const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const os = require('os');

let sock = null;
const NODE_BOT_NUMBER = '6281333148055'; 

function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${d > 0 ? `${d} Hari, ` : ""}${h > 0 ? `${h} Jam, ` : ""}${m > 0 ? `${m} Menit, ` : ""}${s} Detik`;
}

function bytesToGB(bytes) { return (bytes / (1024 * 1024 * 1024)).toFixed(2); }

async function initWhatsApp() {
    const { version } = await fetchLatestBaileysVersion();
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    
    sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: 'silent' }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        syncFullHistory: false
    });

    if (!sock.authState.creds.registered) {
        console.log(`[WA] Mencoba mendaftarkan nomor: ${NODE_BOT_NUMBER} via Pairing Code...`);
        setTimeout(async () => {
            try {
                let code = await sock.requestPairingCode(NODE_BOT_NUMBER);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(`\n🔑 PAIRING CODE ANDA: ${code}\n`);
            } catch (error) { console.error('[WA] Gagal meminta pairing code:', error.message); }
        }, 6000);
    }

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            if (statusCode !== DisconnectReason.loggedOut) { setTimeout(() => { initWhatsApp(); }, 5000); }
        } else if (connection === 'open') { console.log('[WA] WhatsApp Bot SIAP BEROPERASI!'); }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const from = msg.key.remoteJid;
        const body = msg.message.conversation || msg.message.extendedTextMessage?.text || msg.message.imageMessage?.caption;
        if (!body) return;
        
        const command = body.trim().toLowerCase();

        // 1. COMMAND: .uptime
        if (command === '.uptime') {
            const responUptime = `*─── VPS UPTIME STATUS ───*\n\n⏱️ *Uptime:* ${formatUptime(os.uptime())}\n📅 *Waktu Server:* ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB`;
            await sock.sendMessage(from, { text: responUptime }, { quoted: msg });
        }

        // 2. COMMAND: .vps
        else if (command === '.vps') {
            const infoVPS = `*─── VPS HARDWARE SPEC ───*\n\n💻 *CPU Core:* ${os.cpus().length}\n📟 *RAM:* ${bytesToGB(os.totalmem() - os.freemem())} GB / ${bytesToGB(os.totalmem())} GB\n💿 *OS:* ${os.platform()}`;
            await sock.sendMessage(from, { text: infoVPS }, { quoted: msg });
        }

        // 3. COMMAND: .nisa
        else if (command === '.nisa') {
            await sock.sendMessage(from, { text: '⏳ Sedang mengumpulkan data dari Portal NISA, mohon tunggu...' }, { quoted: msg });
            try {
                const { scrapeNisa } = require('../scrapers/nisaScraper');
                const hasilScrape = await scrapeNisa();
                await sock.sendMessage(from, { text: hasilScrape.data }, { quoted: msg });
            } catch (err) { await sock.sendMessage(from, { text: `❌ *Error:* ${err.message}` }, { quoted: msg }); }
        }

        // 4. COMMAND: .cektiket [No Tiket FT]
        else if (command.startsWith('.cektiket')) {
            const args = body.trim().split(/ +/).slice(1);
            const inputTiket = args[0];
            if (!inputTiket) return await sock.sendMessage(from, { text: '❌ *Format Salah!*\nContoh: *\.cektiket FT260600316*' }, { quoted: msg });

            await sock.sendMessage(from, { text: `⏳ Sedang membongkar data pelanggan untuk *${inputTiket}*, mohon tunggu...` }, { quoted: msg });
            try {
                const { cekDetailTiket } = require('../scrapers/nisaScraper');
                const hasilDetail = await cekDetailTiket(inputTiket);
                await sock.sendMessage(from, { text: hasilDetail.data }, { quoted: msg });
            } catch (err) { await sock.sendMessage(from, { text: `❌ *Error:* ${err.message}` }, { quoted: msg }); }
        }

        // 5. COMMAND BARU: .cekfat [No Tiket FT]
        else if (command.startsWith('.cekfat')) {
            const args = body.trim().split(/ +/).slice(1);
            const inputTiket = args[0];
            if (!inputTiket) return await sock.sendMessage(from, { text: '❌ *Format Salah!*\nContoh: *\.cekfat FT260600316*' }, { quoted: msg });

            await sock.sendMessage(from, { text: `⏳ Melakukan Real-time Ping ONT massal untuk tiket *${inputTiket}*, mohon tunggu beberapa saat...` }, { quoted: msg });
            try {
                const { cekStatusFat } = require('../scrapers/nisaScraper');
                const hasilFat = await cekStatusFat(inputTiket);
                await sock.sendMessage(from, { text: hasilFat.data }, { quoted: msg });
            } catch (err) { await sock.sendMessage(from, { text: `❌ *Error:* ${err.message}` }, { quoted: msg }); }
        }
    });
}

async function sendMessage(to, text) {
    if (!sock) return;
    let formatted = to.replace(/[^0-9]/g, '');
    if (formatted.startsWith('0')) formatted = '62' + formatted.slice(1);
    await sock.sendMessage(`${formatted}@s.whatsapp.net`, { text });
}

module.exports = { initWhatsApp, sendMessage };

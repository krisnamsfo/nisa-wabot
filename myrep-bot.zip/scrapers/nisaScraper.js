const axios = require('axios');
require('dotenv').config();

function getBaseHeaders(jwtToken) {
    return {
        'Authorization': `Bearer ${jwtToken}`,
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
        'Referer': 'https://nisa.myrepublic.net.id/'
    };
}

// Helper untuk mencari data tiket berdasarkan Nomor FT atau ID angka
async function temukanTiket(jwtToken, inputTiket) {
    const dcParam = Date.now();
    const listResponse = await axios.get('https://nisa.myrepublic.net.id/api/transaction/fatlossticketing/fatloss-assignment', {
        params: { '_dc': dcParam, 'status_fat': '0', 'workplace': '8', 'userGroup': 'MSFO,Massproblem Only', 'limit': '50' },
        headers: getBaseHeaders(jwtToken)
    });

    const allTickets = listResponse.data?.data || [];
    return allTickets.find(t => t.tlop_no.toUpperCase() === inputTiket.trim().toUpperCase() || String(t.tlop_id) === inputTiket.trim());
}

// 1. MONITORING DAFTAR TIKET
async function scrapeNisa() {
    const jwtToken = process.env.NISA_TOKEN;
    if (!jwtToken) return { success: false, error: 'Token NISA belum diisi di file .env!' };

    try {
        const dcParam = Date.now(); 
        const targetResponse = await axios.get('https://nisa.myrepublic.net.id/api/transaction/fatlossticketing/fatloss-assignment', {
            params: { '_dc': dcParam, 'status_fat': '0', 'workplace': '8', 'userGroup': 'MSFO,Massproblem Only', 'page': '1', 'start': '0', 'limit': '25' },
            headers: getBaseHeaders(jwtToken)
        });

        const ticketData = targetResponse.data;

        if (ticketData && ticketData.success === true) {
            const listTiket = ticketData.data || [];
            if (listTiket.length === 0) {
                return { success: true, data: `🟢 *MONITORING PORTAL NISA*\n\nStatus: *Aman*\nAlhamdulillah, tidak ada tiket gangguan massal (Fatloss) saat ini.` };
            }

            let laporan = `🚨 *MONITORING FATLOSS PORTAL NISA* 🚨\n`;
            laporan += `==================================\n`;
            laporan += `📊 *Ringkasan Tiket Open:* ${ticketData.totalopen || listTiket.length}\n\n`;

            listTiket.forEach((tiket, index) => {
                const isTaken = tiket.tlop_taken_by || tiket.tlop_taken_date;
                const statusTakenText = isTaken ? `🔴 *Status:* Taken (Oleh: ${tiket.tlop_taken_by})` : `🟡 *Status:* Untaken (Belum Diambil)`;

                laporan += `${index + 1}. 📄 *No Tiket:* \`${tiket.tlop_no}\`\n`;
                laporan += `   ${statusTakenText}\n`;
                laporan += `   📁 *Kategori:* ${tiket.tlop_category_name || 'Loss Signal'}\n`;
                laporan += `   📍 *Cluster:* ${tiket.tlop_cluster_name}\n`;
                laporan += `   🔢 *FAT Design/Aktual:* ${tiket.tlop_fdt_code} / ${tiket.tlop_fat_actual || '-'}\n`;
                laporan += `   👥 *Total CID:* ${tiket.total_cid || 0} User\n`;
                laporan += `   🕒 *Aging:* ${tiket.aging_ticket || '-'}\n`;
                laporan += `   💡 _Ketik *\.cektiket ${tiket.tlop_no}* atau *\.cekfat ${tiket.tlop_no}*_\n`;
                laporan += `   ----------------------------------\n`;
            });

            return { success: true, data: laporan };
        } else {
            return { success: false, error: 'Gagal mengambil data dari list assignment.' };
        }
    } catch (error) {
        if (error.response?.status === 403) return { success: false, error: 'Token kedaluwarsa. Sila ambil token baru.' };
        return { success: false, error: error.message };
    }
}

// 2. CEK DETAIL CUSTOMER (CID & WO)
async function cekDetailTiket(inputTiket) {
    const jwtToken = process.env.NISA_TOKEN;
    if (!jwtToken) return { success: false, error: 'Token NISA belum diisi di file .env!' };

    try {
        let tlopId = inputTiket.trim();
        if (tlopId.toUpperCase().startsWith('FT')) {
            const matchedTicket = await temukanTiket(jwtToken, tlopId);
            if (!matchedTicket) return { success: false, error: `Tiket *${tlopId}* tidak ditemukan dalam daftar tiket aktif.` };
            tlopId = matchedTicket.tlop_id;
        }

        const dcParam = Date.now();
        const response = await axios.get('https://nisa.myrepublic.net.id/api/transaction/fatlossticketing/fatutilizationciddtl', {
            params: { '_dc': dcParam, 'tlop_id': tlopId, 'page': '1', 'start': '0', 'limit': '25' },
            headers: getBaseHeaders(jwtToken)
        });

        const resData = response.data;
        if (resData && resData.success === true) {
            const listCid = resData.data || [];
            if (listCid.length === 0) return { success: true, data: `ℹ️ Tidak ditemukan detail data Customer untuk Tiket *${inputTiket}*.` };

            let detailMsg = `🔍 *DETAIL CUSTOMER FATLOSS (${inputTiket.toUpperCase()})* 🔍\n`;
            detailMsg += `📍 *Cluster:* ${listCid[0].tlos_cluster_name}\n`;
            detailMsg += `==================================\n\n`;

            listCid.forEach((cust, idx) => {
                detailMsg += `${idx + 1}. 👤 *CID:* ${cust.tlos_customer_id}\n`;
                detailMsg += `   🛠️ *No WO:* ${cust.tlos_wo_number || '_Belum Terbit_'}\n`;
                detailMsg += `   🎫 *No Tiket CRM:* ${cust.tlos_ticket_number || '_Belum Terbit_'}\n`;
                detailMsg += `   ----------------------------------\n`;
            });

            return { success: true, data: detailMsg };
        } else {
            return { success: false, error: resData.msg || 'Gagal menarik data detail pelanggan.' };
        }
    } catch (error) {
        if (error.response?.status === 403) return { success: false, error: 'Token kedaluwarsa. Sila ambil token baru.' };
        return { success: false, error: error.message };
    }
}

// 3. FUNGSI BARU: CEK STATUS ONT / PING FAT MASSAL
async function cekStatusFat(inputTiket) {
    const jwtToken = process.env.NISA_TOKEN;
    if (!jwtToken) return { success: false, error: 'Token NISA belum diisi di file .env!' };

    try {
        // Cari tiket untuk mendapatkan tlop_id dan string kumpulan customer_id (CID)
        const matchedTicket = await temukanTiket(jwtToken, inputTiket);
        if (!matchedTicket) {
            return { success: false, error: `Tiket *${inputTiket}* tidak ditemukan atau sudah closed.` };
        }

        const tlopId = matchedTicket.tlop_id;
        const rawCids = matchedTicket.tlos_customer_id; // Hasilnya berupa string koma: "4183507,4446093"

        if (!rawCids) {
            return { success: false, error: `Tidak ada data Customer ID (CID) yang terikat di tiket *${inputTiket}*.` };
        }

        const arrCids = rawCids.split(',');
        const dcParam = Date.now();

        // Menyusun parameter query pencarian
        const queryParams = new URLSearchParams();
        queryParams.append('_dc', dcParam);
        arrCids.forEach(cid => queryParams.append('data', cid.trim())); // Meniru struktur &data=4183507&data=4446093
        queryParams.append('tlos_id', tlopId);
        queryParams.append('customer_id', rawCids);

        console.log(`[Scraper] Melakukan pengecekan status ONT massal untuk Tiket ${inputTiket}...`);

        const response = await axios.get('https://nisa.myrepublic.net.id/api/transaction/fatlossticketing/check-ont-status', {
            params: queryParams,
            headers: getBaseHeaders(jwtToken)
        });

        const resData = response.data;

        if (resData && resData.success === true) {
            const listOnt = resData.data || [];
            if (listOnt.length === 0) return { success: true, data: `ℹ️ Tidak ada respon status ONT dari server untuk tiket *${inputTiket}*.` };

            let statusMsg = `📡 *HASIL CEK STATUS ONT FAT / CLUSTER* 📡\n`;
            statusMsg += `📄 *No Tiket:* ${matchedTicket.tlop_no}\n`;
            statusMsg += `📍 *Cluster:* ${matchedTicket.tlop_cluster_name}\n`;
            statusMsg += `==================================\n\n`;

            listOnt.forEach((ont, idx) => {
                const emojiStatus = ont.ont_status === 'online' ? '🟢' : '🔴';
                const redaman = ont.rx_level ? `${ont.rx_level} dBm` : '_Loss Signal / Offline_';
                
                statusMsg += `${idx + 1}. 👤 *CID:* ${ont.cid}\n`;
                statusMsg += `   ⚡ *Status ONT:* ${emojiStatus} *${ont.ont_status.toUpperCase()}*\n`;
                statusMsg += `   📉 *Rx Level (Redaman):* ${redaman}\n`;
                statusMsg += `   ⚙️ *F/S/P/ID:* ${ont.frame || 0}/${ont.slot || 0}/${ont.port || 0}/${ont.ont_id || 0}\n`;
                statusMsg += `   🧮 *SN ONT:* ${ont.serial_number || '-'}\n`;
                statusMsg += `   🌡️ *Temperatur:* ${ont.temperature ? `${ont.temperature}°C` : '-'}\n`;
                statusMsg += `   ----------------------------------\n`;
            });

            statusMsg += `\n⚡ _Selesai mengecek status ONT via Real-time Ping._`;
            return { success: true, data: statusMsg };
        } else {
            return { success: false, error: resData.msg || 'Gagal mengecek status ONT massal.' };
        }

    } catch (error) {
        if (error.response?.status === 403) return { success: false, error: 'Token kedaluwarsa. Silakan ambil token baru dari browser.' };
        return { success: false, error: error.message };
    }
}

module.exports = { scrapeNisa, cekDetailTiket, cekStatusFat };
